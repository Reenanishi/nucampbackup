//
//  CartController.swift
//  FoodieApp
//
//  Created by Ankur Pandey on 12/17/18.
//  Copyright © 2018 foodie. All rights reserved.
//

import Foundation
import UIKit


class CartTableCell: UITableViewCell {
    var foodWrapper : FoodWrapper!

    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var restaurantName: UILabel!
    @IBOutlet weak var foodName: UILabel!
    @IBOutlet weak var foodPic: UIImageView!
    @IBOutlet weak var price: UILabel!
    
    var buttonAction: ((Any) -> Void)?
    
    @IBAction func removeFromCart(_ sender: Any) {
        self.buttonAction?(sender)
    }
}

class CartController: UIViewController, UITableViewDataSource {

    @IBOutlet weak var cartTable: UITableView?
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myCart.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CartTableCell", for: indexPath) as! CartTableCell
        let choice = myCart[indexPath.row]
        cell.foodWrapper = choice
        
        cell.restaurantName?.text = choice.restaurantName
        
        cell.foodName?.text = choice.food.foodName
        cell.price?.text = choice.food.price
        cell.rating?.text = choice.food.rating
        cell.foodPic?.image = UIImage(named: choice.food.foodPic)
        cell.buttonAction = { sender in
            let isIndexValid = myCart.indices.contains(indexPath.row)
            if isIndexValid {
            myCart.remove(at: indexPath.row)
            self.cartTable?.reloadData()
            }
        }
        return cell
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.cartTable?.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cartTable?.dataSource = self
        self.cartTable?.reloadData()
    }
}


