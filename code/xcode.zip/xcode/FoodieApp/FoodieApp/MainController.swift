
//
//  ViewController.swift
//  FoodieApp
//
//  Created by Ankur Pandey on 12/16/18.
//  Copyright © 2018 foodie. All rights reserved.
//

import UIKit

class RestaurantsCell: UITableViewCell {
    var restaurant : Restaurant!
    @IBOutlet weak var restaurantName: UILabel!
    @IBOutlet weak var restaurantAddress: UILabel!
    @IBOutlet weak var restaurantType: UILabel!
    @IBOutlet weak var restaurantRating: UILabel!
    @IBOutlet weak var foodPic: UIImageView!
}


class recoMainFoodCell: UICollectionViewCell {
    
    var foodWrapper : FoodWrapper!

    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var restaurantNameLabel: UILabel!
    @IBOutlet weak var foodNameLabel: UILabel!
    @IBOutlet weak var foodPicLabel: UIImageView!
    @IBOutlet weak var priceLabel: UILabel!
    @IBAction func addToCart(_ sender: Any) {
        myCart.append(foodWrapper)
    }
}

class MainController: UIViewController, UITableViewDataSource, XMLParserDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UISearchBarDelegate{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return foodRecoMain.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "recoMainFoodCell", for: indexPath) as! recoMainFoodCell
        
        let object = foodRecoMain[indexPath.row]
        cell.foodWrapper = object
        cell.restaurantNameLabel?.text = object.restaurantName
        cell.priceLabel?.text = object.food.price
        cell.ratingLabel?.text = object.food.rating
        cell.foodNameLabel?.text = object.food.foodName
        cell.foodPicLabel?.image = UIImage(named: object.food.foodPic)
        return cell
    }
    
    // method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // Segue to the second view controller
        self.performSegue(withIdentifier: "ResturantViewSegue", sender: self)
    }

    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       if segue.identifier == "ResturantViewSegue" {
            if let nextViewController = segue.destination as? ResturantViewController {
                let indexPath = restaurantMainView.indexPathForSelectedRow
                //let object = resturants[indexPath.row]
                nextViewController.restaurant = allrestaurants[(indexPath?.row)!]    //Or pass any values
            }
        }
    }
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var foodRecoCollectionView: UICollectionView!
    @IBOutlet weak var restaurantMainView: UITableView!
    

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allrestaurants.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RestaurantsCell", for: indexPath) as! RestaurantsCell
        let proCell = allrestaurants[indexPath.row]
        cell.restaurantName?.text = proCell.restaurantName
        let substr = proCell.address
        let index = substr.index(substr.startIndex, offsetBy: 32)
        let myRange = ..<index    // Hello
        cell.restaurantAddress?.text = String(substr[myRange])
        cell.restaurantType?.text = proCell.type
        cell.restaurantRating?.text = proCell.rating
        cell.foodPic?.image = UIImage(named: proCell.menu[0].foodPic)
        cell.restaurant = proCell
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        restaurantMainView.dataSource = self
        if let path = Bundle.main.url(forResource: "Foodie", withExtension: "xml") {
            if let parser = XMLParser(contentsOf: path) {
                parser.delegate = self
                parser.parse()
                //print(self.resturants)
            }
            //print(self.resturants)
        }
        foodRecoMain = foodRecoMain.sorted(by: { $0.food.rating > $1.food.rating })

    }
    
    
    func parserDidStartDocument(_ parser: XMLParser) {
        allrestaurants = []
    }
    
    
    var foodName = ""
    var restaurantName  = ""
    var restaurantAddress  = ""
    var price = ""
    var ratingRecommand = ""
    var foodPic = ""
    var foods = [Food]()
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        //print(elementName)
        if elementName == "Restaurant" {
            restaurantName = attributeDict["Name"]!
            restaurantAddress = attributeDict["Location"]!
        }
        if elementName == "food" {
            foodName = attributeDict["name"]!
            price = attributeDict["Price"]!
            ratingRecommand = attributeDict["Rating"]!
            foodPic = attributeDict["pic"]!
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "food" {
            let foodcur : Food = Food(
                foodCategory: "MainCourse",
                foodName: foodName,
                price: price,
                rating: ratingRecommand,
                likedDisLikedCount: "4",
                numberOfTimesOrdered: "45",
                foodPic: foodPic)
            
            foods.append(foodcur)
            foodRecoMain.append(FoodWrapper( food : foodcur,
                                             restaurantName : restaurantName,
                                             restaurantAddress : restaurantAddress))
            foodName = ""
            price = ""
            ratingRecommand = ""
            foodPic = ""
        }
      
        if elementName == "Restaurant" {
            allrestaurants.append(
                Restaurant(
                    restaurantName: restaurantName,
                    address: restaurantAddress,
                    rating : "4.2",
                    type: "Indian",
                    foodPic : "Burger" ,
                    menu : foods)
            )
            foods.removeAll()
            restaurantName = ""
            restaurantAddress = ""
            
        }
        
    }
        
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        //print(parseError)
        foodName = ""
        price = ""
        ratingRecommand = ""
        foodPic = ""
        restaurantName = ""
        restaurantAddress = ""
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        // filterdata  = searchText.isEmpty ? data : data.filter {(item : String) -> Bool in
        
//        filterdata = searchText.isEmpty ? searchText : data.filter { $0.contains(searchText) }
//
        searchBar.text = searchText
        //return item.range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil
        //tblview.reloadData()
//        searchBar.resignFirstResponder()
//        searchBar.endEditing(true)
    }
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
//        if !shouldShowSearchResults {
//            shouldShowSearchResults = true
//            tblSearchResults.reloadData()
//        }
        
        searchBar.resignFirstResponder()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        searchBar.resignFirstResponder()
        searchBar.endEditing(true)
        self.view.endEditing(true)
    }
}

