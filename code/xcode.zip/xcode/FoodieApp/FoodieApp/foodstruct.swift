//
//  foodstruct.swift
//  FoodieApp
//
//  Created by Ankur Pandey on 12/18/18.
//  Copyright © 2018 foodie. All rights reserved.
//

import Foundation



var myCart = [FoodWrapper]()
var foodRecoMain = [FoodWrapper]()
var allrestaurants = [Restaurant]()

struct Food {
    var foodCategory : String
    var foodName : String
    var price : String
    var rating : String
    var likedDisLikedCount : String
    var numberOfTimesOrdered : String
    var foodPic : String
}

struct Restaurant {
    var restaurantName : String
    var address : String
    var rating : String
    var type : String
    var foodPic : String
    var menu : [Food]!
}

struct FoodWrapper {
    var food : Food!
    var restaurantName : String
    var restaurantAddress : String
}
