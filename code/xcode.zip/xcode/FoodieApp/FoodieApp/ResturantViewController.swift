


import UIKit

class MenuCell: UITableViewCell {
    var foodWrapper : FoodWrapper!
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var foodName: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var foodPic: UIImageView!
    @IBAction func addToCart(_ sender: Any) {
        myCart.append(foodWrapper)
        //print(myCart)
    }
}

class EndorsedFoodNearByCell: UICollectionViewCell {
    
    var foodWrapper : FoodWrapper!
    
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var restaurantNameLabel: UILabel!
    @IBOutlet weak var foodNameLabel: UILabel!
    @IBOutlet weak var foodPicLabel: UIImageView!
    @IBOutlet weak var priceLabel: UILabel!
    @IBAction func addToCart(_ sender: Any) {
        //print ("Added to cart")
        myCart.append(foodWrapper)
        print(myCart)
    }
}

class EndorsedFoodAtThisCell: UICollectionViewCell {
    
    var foodWrapper : FoodWrapper!
    
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var foodNameLabel: UILabel!
    @IBOutlet weak var foodPicLabel: UIImageView!
    @IBOutlet weak var priceLabel: UILabel!
    @IBAction func addToCart(_ sender: Any) {
        //print ("Added to cart")
        myCart.append(foodWrapper)
        print(myCart)
    }
}

class ResturantViewController: UIViewController, UITableViewDataSource, UICollectionViewDataSource, UICollectionViewDelegate{
    
    @IBOutlet weak var endorsedAtThisCollView: UICollectionView!
    @IBOutlet weak var endorsedFoodAtThisRestaurantLabel: UILabel!
    
    @IBOutlet weak var endorsedNearBy: UICollectionView!
    @IBOutlet weak var menuOfRestaurantLabel: UILabel!
    
    @IBOutlet weak var restaurantTable: UITableView!
    
    var restaurant : Restaurant!
    var thisRestaurantReco = [Food]()


    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurant.menu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuCell", for: indexPath) as! MenuCell
        let object = restaurant.menu[indexPath.row]
        
        cell.foodWrapper = FoodWrapper( food : object,
        restaurantName : restaurant.restaurantName,
        restaurantAddress : restaurant.address)
        
        cell.foodName?.text = object.foodName
        cell.price?.text = object.price
        cell.rating?.text = object.rating
        cell.foodPic?.image = UIImage(named: object.foodPic)
        return cell
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.title = restaurant.restaurantName
        self.thisRestaurantReco = restaurant.menu
        thisRestaurantReco = thisRestaurantReco.sorted(by: { $0.rating > $1.rating })
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = restaurant.restaurantName
        self.thisRestaurantReco = restaurant.menu
        thisRestaurantReco = thisRestaurantReco.sorted(by: { $0.rating > $1.rating })

        restaurantTable.dataSource = self
        endorsedAtThisCollView.delegate = self as UICollectionViewDelegate
        endorsedAtThisCollView.delegate = self as UICollectionViewDelegate
        
        endorsedNearBy.dataSource = self as UICollectionViewDataSource
        endorsedNearBy.dataSource = self as UICollectionViewDataSource

    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.endorsedAtThisCollView {
            return thisRestaurantReco.count
        }else{
           return foodRecoMain.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.endorsedAtThisCollView {
            let endorsedFoodAtThisCell = collectionView.dequeueReusableCell(withReuseIdentifier: "EndorsedFoodAtThisCell", for: indexPath) as! EndorsedFoodAtThisCell
            
            let object = thisRestaurantReco[indexPath.row]
            endorsedFoodAtThisCell.foodWrapper = FoodWrapper( food : object,
                                                              restaurantName : restaurant.restaurantName,
                                                              restaurantAddress : restaurant.address)
            
            endorsedFoodAtThisCell.priceLabel?.text = object.price
            endorsedFoodAtThisCell.ratingLabel?.text = object.rating
            endorsedFoodAtThisCell.foodNameLabel?.text = object.foodName
            endorsedFoodAtThisCell.foodPicLabel?.image = UIImage(named: object.foodPic)
            
            return endorsedFoodAtThisCell
        }else {
            let endorsedFoodNearByCell = collectionView.dequeueReusableCell(withReuseIdentifier: "EndorsedFoodNearByCell", for: indexPath) as! EndorsedFoodNearByCell
        
            let object = foodRecoMain[indexPath.row]
            
            endorsedFoodNearByCell.foodWrapper = object
            endorsedFoodNearByCell.restaurantNameLabel?.text = object.restaurantName
            endorsedFoodNearByCell.priceLabel?.text = object.food.price
            endorsedFoodNearByCell.ratingLabel?.text = object.food.rating
            endorsedFoodNearByCell.foodNameLabel?.text = object.food.foodName
            endorsedFoodNearByCell.foodPicLabel?.image = UIImage(named: object.food.foodPic)
        
            return endorsedFoodNearByCell
        }
    }
}
