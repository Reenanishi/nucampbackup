//
//  MainTableView.swift
//  Foodie
//
//  Created by Ankur Pandey on 12/5/18.
//  Copyright © 2018 foodie. All rights reserved.
//

import UIKit

struct MainDataStruct {
    var foodName : String
    var resturantName : String
    var resturantAddress : String
    var price : String
    var ratingRecommand : String
    var foodPic : String
}

class OptionTableViewCell: UITableViewCell {
    @IBOutlet weak var foodName: UILabel!
    @IBOutlet weak var resturantName: UILabel!
    @IBOutlet weak var resturantAddress: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var ratingandrecommand: UILabel!
    @IBOutlet weak var foodPic: UIImageView!
    
}
