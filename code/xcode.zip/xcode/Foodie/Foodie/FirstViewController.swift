//
//  FirstViewController.swift
//  Foodie
//
//  Created by Ankur Pandey on 12/2/18.
//  Copyright © 2018 foodie. All rights reserved.
//

import UIKit
class FirstViewController: UIViewController, UITableViewDataSource, XMLParserDelegate{
    @IBOutlet weak var mainTable: UITableView!
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    // MARK: - Table view data source

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if(section == 0){
            return "Recommended Food Near You"
        }
        return "Recommended Resturant Near You"
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OptionTableViewCell", for: indexPath) as! OptionTableViewCell
        
        let proCell = resturants[indexPath.row]
        cell.foodName?.text = proCell.foodName
        cell.resturantName?.text = proCell.resturantName
        cell.resturantAddress?.text = proCell.resturantAddress
        cell.price?.text = "$" + proCell.price
        cell.ratingandrecommand?.text = proCell.ratingRecommand + "*"
        cell.foodPic?.image = UIImage(named: proCell.foodPic)
        
        return cell
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        mainTable.dataSource = self
        if let path = Bundle.main.url(forResource: "Foodie", withExtension: "xml") {
            if let parser = XMLParser(contentsOf: path) {
                parser.delegate = self as? XMLParserDelegate
                parser.parse()
                print(self.resturants)
            }
            print(self.resturants)
        }
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func parserDidStartDocument(_ parser: XMLParser) {
        resturants = []
    }
    
    var resturants = [MainDataStruct]()
    
    
    var foodName = ""
    var resturantName  = ""
    var resturantAddress  = ""
    var price = ""
    var ratingRecommand = ""
    var foodPic = ""
    
    //<food Rating="4.0" Type="Appetizer" TopPick="2" Price="45" OrderCount="10" name="GolGape" />
    
    // start element
    //
    // - If we're starting a "record" create the dictionary that will hold the results
    // - If we're starting one of our dictionary keys, initialize `currentValue` (otherwise leave `nil`)
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        if elementName == "Restaurant" {
            resturantName = attributeDict["Name"]!
            resturantAddress = attributeDict["Location"]!
        }
        if elementName == "food" {
           foodName = attributeDict["name"]!
           price = attributeDict["Price"]!
           ratingRecommand = attributeDict["Rating"]!
           foodPic = attributeDict["pic"]!
        }
    }
    
//    // found characters
//    //
//    // - If this is an element we care about, append those characters.
//    // - If `currentValue` still `nil`, then do nothing.
//
//    func parser(_ parser: XMLParser, foundCharacters string: String) {
//        currentValue? += string
//    }
    
    // end element
    //
    // - If we're at the end of the whole dictionary, then save that dictionary in our array
    // - If we're at the end of an element that belongs in the dictionary, then save that value in the dictionary
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "food" {
            resturants.append(MainDataStruct(foodName: foodName, resturantName: resturantName,
                                             resturantAddress: resturantAddress, price: price,
                                             ratingRecommand: ratingRecommand, foodPic: foodPic))
            foodName = ""
            price = ""
            ratingRecommand = ""
            foodPic = ""
        }
        if elementName == "Restaurant" {
            resturantName = ""
            resturantAddress = ""
        }
        
    }
    
    // Just in case, if there's an error, report it. (We don't want to fly blind here.)
    
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        print(parseError)
        foodName = ""
        price = ""
        ratingRecommand = ""
        foodPic = ""
        resturantName = ""
        resturantAddress = ""
    }

}
